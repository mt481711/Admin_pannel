<?php

session_start();

if (!isset($_SESSION['email'])) {
	header('Location: login/login.php');
	exit;
}
?>

<?php
include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
   
  
</head>
<body>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    
     <!-- user info -->
       <div class="card">
     <div class="card text-bg-light mb-3" style="width: 50%; height:500px;margin-left:300px;">
  <div class="card-header">User Details</div>
  <div class="card-body">
    <h5 class="card-title">Edit Info:</h5>
    <p class="card-text"><form action="" method="POST"enctype="multipart/form-data">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" name = "name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder = "Name of Product">
    
  </div>
 
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Image</label>
    <input type="file" class="form-control" name = "image"id="exampleInputPassword1" >
  </div>
 
  <button type="submit" name="add" class="btn btn-primary">Add</button>
</form></p>
  </div>
</div>
</div>





</body>
</html>
 




<?php
 $conn = mysqli_connect('localhost','root','','phplogin');
 
 
 if ( mysqli_connect_errno() ) {
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
 if(isset($_POST['add'])){


    
     $n = $_POST['name'];
    
     $image = $_FILES['image']['name'];
     $tmp_name = $_FILES['image']['tmp_name'];
     $path = "catimg/".$image;
     move_uploaded_file($tmp_name,$path);
    
     $sql = "INSERT INTO mainc (name,image)VALUES('$n','$image')";
    $result = mysqli_query($conn,$sql);
    echo "<script>
    window.open('mainc.php','_self');
            </script>";
  
  }

?>
