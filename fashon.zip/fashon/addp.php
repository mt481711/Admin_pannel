<?php

session_start();

if (!isset($_SESSION['email'])) {
	header('Location: login/login.php');
	exit;
}
?>

<?php
include "includes/config.php";
include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php"; 

 if(isset($_POST['submit'])){
     $n = $_POST['name'];
     $p = $_POST['price'];
     $d = $_POST['description'];
    
     $image = $_FILES['image']['name'];
     $tmp_name = $_FILES['image']['tmp_name'];
     $path = "catimg/".$image;
     move_uploaded_file($tmp_name,$path);
    
     $sql = "INSERT INTO product (name,price,description,image)VALUES('$n','$p','$d','$image')";
    $result = mysqli_query($conn,$sql);
    echo "<script>
    window.open('index.php','_self');
            </script>";
  
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
   
  
</head>
<body>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    
     <!-- user info -->
       <div class="card">
     <div class="card text-bg-light mb-3" style="width: 50%; height:900px;margin-left:300px;">
  <div class="card-header">Product Details</div>
  <div class="card-body">
    <h5 class="card-title">Add Info:</h5>
    <p class="card-text"><form action="" method="POST"enctype="multipart/form-data">
    <div class="mb-3">
                          <label>product_categary</label>
                              <select class="form-control" name="cat_name" onchange="get_sub_cat()" id="cat_name">
                                <option value="">Select Category</option>
                              <?php
                              
                              $sql = "SELECT * FROM mainc";
                          $result = mysqli_query($conn,$sql);
                          if (mysqli_num_rows($result)) {
                            while ($row = mysqli_fetch_assoc($result)) {
                              ?>
                              <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                              <?php
                            }
                          }
                          ?>
                          </select>
                      </div>

                      <div class="mb-3">
                          <label>product_Sub_categary</label>
                              <select class="form-control" name="sub_name" id="sub_name" required>
                                <option value="">Select_subCategory</option>
                          </select>
                      </div>




  <div class="mb-3">
    <label  class="form-label">Name</label>
    <input type="text" class="form-control" name = "name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder = "Name of Product">
    
  </div>
  <div class="mb-3">
    <label  class="form-label">Price</label>
    <input type="varchar" class="form-control" name = "price" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder = "Price of Product">
    
  </div>
  <div class="mb-3">
    <label  class="form-label">Description</label>
    <input type="text" class="form-control" name = "description" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder = "Description of Product">
    
  </div>
 
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Image</label>
    <input type="file" class="form-control" name = "image"id="exampleInputPassword1" >
  </div>
 
  <button type="submit" name="submit" class="btn btn-primary">Add</button>
</form></p>
  </div>
</div>
</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
  <script>
   function get_sub_cat(){
      var cat_name = jQuery('#cat_name').val();
      jQuery.ajax({
        url:'get_sub_cat.php',
        type:'post',
        data:'cat_name='+cat_name,
        success:function(result){
          jQuery('#sub_name').html(result);
        }
      })
    }
  </script>
</body>
</html>
 

